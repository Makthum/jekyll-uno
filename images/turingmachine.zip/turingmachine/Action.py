__author__ = 'Makthum'
#this class is to store actions on the transition table
class Action:
    def __init__(self,charwrite,mvdir,nxtstate):
        self.char_write=charwrite
        self.move_direction=mvdir
        self.next_state=nxtstate

