__author__ = 'Makthum'

#this class is to store different states in action table
class State:
    def __init__(self,state,charread):
        self.init_state=state
        self.char_read=charread
    def __hash__(self):
        return hash((self.init_state, self.char_read))

    def __eq__(self, other):
        return (self.init_state==other.init_state) and  (self.char_read == other.char_read)



