__author__ = 'Makthum'
class Tape(object):
    blank_symbol = " "
    def __init__(self,
                 input=""):
        self.__tape = {}
        for i in range(len(input)):
            self.__tape[i] = input[i]

#returns the character at the given index position on the tape
    def getchar(self,index):
        if index in self.__tape:
            return self.__tape[index]
        else:
            return ""

    def setchar(self,char,index):
        self.__tape[index]=char

    def __str__(self):
        s = ""
        for ss in self.__tape:
            s=s+self.__tape[ss]
        return s
    def len(self):
        return len(self.__tape)