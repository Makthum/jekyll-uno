import getopt
import sys
from Action import Action
from State import State
from Tape import Tape

#sys.path.append()
__author__ = 'Makthum'


class TuringMachine(object):
    def __init__(self,inputfile):
        self.actiontable = {}
        self.start_position=0
        self.headposition=0
        self.start_state='0'
        self.final_state='0'
        self.inputfile=inputfile
        self.hits={}
        self.init()
        self.headposition = self.start_position
        self.currentstate = self.start_state



    '''This function is to read the input file and initialize turing machine object with the values from the input file'''
    def init(self):
        # open input file
        f = open(self.inputfile)

        # Read first line into tape
        # Assuming tape is finite since in the document it was mentioned tape size is small. If Tape is considered infinite it would
        # efficient to read blocks of data into tape and run turring machine on it instead reading on character at a time.

        #charactes aren't read in newline since definition may or maynot end in newline character
        # First line is read into Tape
        char = f.readline().rstrip("\n")
        if char:
            self.tape = Tape(char)

        # Read starting position of the head
        char = f.read(2).rstrip("\n").strip("-")
        if not char:
            self.start_position = char

        #Read start state
        char = f.read(2).rstrip("\n")
        if not char:
            self.start_state = char

        # Read final state
        char = f.read(2).rstrip("\n")
        if char:
            self.final_state = char

        #Read action table and store them in key, value pairs
        #if read fails break out of the loop assuming EOF has been reached
        while True:
            # Read action table
            # Todo: check null values
            initiat_state = f.read(2).rstrip()
            if not initiat_state: break
            character_read = f.read(2).rstrip()
            if not character_read: break
            state = State(initiat_state, character_read)
            charwrite = f.read(2).rstrip()
            if not charwrite: break

            #hardcoded hack is used to read move direction since -1 has extra character in terms of '-'
            movedirection = f.read(1)
            if (movedirection == "-"):
                movedirection = movedirection + f.read(2).rstrip()
            else:
                movedirection = movedirection + f.read(1).rstrip()
            if not movedirection: break
            nextstate = f.read(2).rstrip().rstrip("\n")
            if not nextstate: break

            #store key value pairs
            action = Action(charwrite, movedirection, nextstate)
            self.actiontable[state] = action
            self.hits[state]=0






            #prints the contents of the tape

    def print_tape(self):
        # print contents of the tape
        print(self.tape)


    ''' This method executes turing machine step by step following the state-Action table formed using the input'''


    def execute(self):
        # self.printActionTable()
        i=0
        while self.currentstate != self.final_state:

            # Determing the current state
            currentState = State(self.currentstate, Tape.getchar(self.tape, self.headposition))

            #Based on current state determine the action. if no state-action rule is found halt the turing machine
            action = self.findAction(currentState)
            if action is None:
                print("No rule detected. Halting ")
                break
            #if wild-card character is encountered in write. Do write anything
            if (action.char_write != '*'):
                Tape.setchar(self.tape, action.char_write, self.headposition)

            #move the headposition
            self.headposition = self.headposition + int(action.move_direction)

            #set current state from the action table
            self.currentstate = action.next_state

            #halt the turing machine if head reaches end of tape
            if self.headposition < 0 or self.headposition > self.tape.len():
                break

            #print tape content at end of each iteration
            print('Step %d  :' %i)
            print('---------')
            i=i+1
            self.print_tape()
            print('\n')
            self.updatehit(State(self.currentstate,Tape.getchar(self.tape, self.headposition)))
        #to update halting state update once more
        self.updatehit(State(self.currentstate,Tape.getchar(self.tape, self.headposition)))
        self.showhits()

    ''' This function determines the next action based on the current state
    it first check for any distinct rules , if not found it checks wild card rule before returning None'''


    def findAction(self, state):
        for key in self.actiontable:
            if (key == state):
                return self.actiontable[key]
            elif (key == State(state.init_state, '*')):
                return self.actiontable[key]
        return None


    ''' This method can be used to show now of states and no of hits per state'''
    # Todo: modifiy output format
    def printActionTable(self):
        for state, action in self.actiontable.iteritems():
            print state.init_state, state.char_read, action.char_write, action.move_direction, action.next_state

    def updatehit(self,state):
         for key in self.hits:
            if (key == state):
                self.hits[key]=self.hits[key]+1
            elif (key == State(state.init_state, '*')):
                 self.hits[key]=self.hits[key]+1


    def showhits(self):
        print ('state :  \tcharacterRead :  \tNoofHits')
        for key in self.hits:
            print('state :%s\tcharacter Read:%s\tNo of Hits:%s'%(key.init_state,key.char_read,self.hits[key]))

def run():
    try:
        myopts, args = getopt.getopt(sys.argv[1:], "i:o:")
        inputfile=''
    except getopt.GetoptError as e:
        print (str(e))
        print("Usage: %s -i input" % sys.argv[0])
        sys.exit(2)
    if not myopts:
        print("Usage: %s -i input" % sys.argv[0])
    for o,a in myopts:
        if o == '-i':
            inputfile = a
            t=TuringMachine(inputfile)
            t.execute()
        else:
            print("Usage -i Inputfile Name")



if __name__=='__main__':
        run()

